package com.testapp.myfinaltest

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_bucket_list.*

class BucketListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bucket_list)

        // Set click listener for "Add new bucket list item" button
        addBucketListItemButton.setOnClickListener {
            startActivity(Intent(this, AddBucketListItemActivity::class.java))
        }

        // Set click listener for "Add destination" button
        addDestinationButton.setOnClickListener {
            startActivity(Intent(this, AddDestinationActivity::class.java))
        }
    }
}
