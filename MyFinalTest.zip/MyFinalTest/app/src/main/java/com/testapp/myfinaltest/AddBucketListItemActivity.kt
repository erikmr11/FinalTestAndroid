package com.testapp.myfinaltest

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_add_bucket_list_item.*

class AddBucketListItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_bucket_list_item)

        // Assuming you have a method to store the information on button click
        submitButton.setOnClickListener {
            // Store the information here

            // After successfully storing the information, navigate back to MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // Finish the current activity to prevent going back to it when pressing back button
            finish()
        }
    }
}
