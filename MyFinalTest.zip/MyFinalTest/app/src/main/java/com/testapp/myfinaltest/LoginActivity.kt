package com.testapp.myfinaltest

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()

        // Set click listener for the login button
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Perform input validation if needed

            // Sign in user with email and password
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Login success, update UI or navigate to next screen
                        Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                        // Redirect user to main activity
                        startActivity(Intent(this, MainActivity::class.java))
                    } else {
                        // Login failed, display an error message to the user
                        Toast.makeText(baseContext, "Login failed: ${task.exception?.message}",
                            Toast.LENGTH_SHORT).show()
                    }
                }
        }

        // Set click listener for the sign-up text
        signUpText.setOnClickListener {
            // Redirect user to sign-up activity
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }
}

